-- Update product images to use available files
UPDATE product_images SET url = '/assets/images/product1.jpg' WHERE "productId" = 'cmbmmf3zy0005tp17pjfvs4nm';
UPDATE product_images SET url = '/assets/images/product2.jpg' WHERE "productId" = 'cmbmmf40c0009tp17yebnet2a';
UPDATE product_images SET url = '/assets/images/product1.jpg' WHERE "productId" = 'cmbmmf40f000dtp1741wcosa3';
UPDATE product_images SET url = '/assets/images/product2.jpg' WHERE "productId" = 'cmbmmf40i000htp17mve6o5co';
UPDATE product_images SET url = '/assets/images/product1.jpg' WHERE "productId" = 'cmbmmf40m000ltp17x0bk4u7v';
UPDATE product_images SET url = '/assets/images/product2.jpg' WHERE "productId" = 'cmbmmf40p000ptp17dxfgefbe';
UPDATE product_images SET url = '/assets/images/product1.jpg' WHERE "productId" = 'cmbmmf40s000ttp17t3k60aw6';